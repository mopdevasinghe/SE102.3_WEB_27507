<?php

$fruits = array("Apple", "Banana", "Orange", "Grapes", "Mango");


foreach ($fruits as $fruit) {
    echo $fruit . "\n";
}
?>